<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="css/style.css">
</head>
<body >

<style>
body{
	background-image:url('images/1.jpg');
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:100% 100%;
}
</style>
	
	<div id="main-wrapper">
		<center>
			<h2>LOGOUT</h2>
			<h3>Goodbye
				<?php echo $_SESSION['username'] ?>
			</h3>
			<img src="imgs/avatar.png" class="avatar"/>
		</center>
	
		<form class="myform" action="logout.php" method="post">
			<input name="logout" type="submit" id="logout_btn" value="Log Out"/><br>
			
		</form>
		
		<?php
			if(isset($_POST['logout']))
			{
				session_destroy();
				header('location:index.php');
			}
		?>
	</div>
</body>
</html>