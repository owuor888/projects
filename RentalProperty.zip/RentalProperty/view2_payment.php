<?php 
    
    require_once('./Payment_config/dbconfig.php'); 
    $db = new operations();
    $result=$db->view_record();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>View Payment</title>
</head>
<body class="bg-dark">

    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark">VIEW PAYMENT </h2>
                    </div>
                    <div class="card-body">
                        <?php
                              $db->display_message(); 
                              $db->display_message();
                        ?>
                        <table class="table table-bordered">
                            <tr>
                                <td style="width: 10%"> ID </td>
                                <td style="width: 10%"> Apartment Name </td>
                                <td style="width: 10%"> Apartment Owner</td>
                                <td style="width: 20%"> Amount Paid </td>
                                <td style="width: 20%"> Date Paid </td>
                                <td style="width: 20%"> Payment Status</td>
                                <td style="width: 20">Operations</td>
                            </tr>
                            <tr>
                                <?php 
                                    while($data = mysqli_fetch_assoc($result))
                                    {
                                ?>
                                    <td><?php echo $data['ID'] ?></td>
                                    <td><?php echo $data['ApartmentName'] ?></td>
                                    <td><?php echo $data['ApartmentOwner'] ?></td>
                                    <td><?php echo $data['AmountPaid'] ?></td>
                                    <td><?php echo $data['DatePaid'] ?></td>
                                    <td><?php echo $data['PaymentStatus'] ?></td>
                                    <td><a href="print.php?pid=<?php echo $data['ID'] ?>" <button class='btn btn-primary'> <i class='fa fa-print' ></i> Print</button></a></td>

                            </tr>
                            <?php
                                    }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>