<?php 
    require_once('./Rent_config/dbconfig.php'); 
    $db = new operations();
    $db->update();
    $id = $_GET['U_ID'];
    $result = $db->get_record($id);
    $data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>Edit Rent</title>
</head>
<body class="bg-dark">

    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2> UPDATE RENT & UTILITIES </h2>
                    </div>
                        <?php $db->Store_Record(); ?>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="ID" value="<?php echo $data['ID']; ?>">
                                <input type="text" name="Rent" placeholder=" Rent" class="form-control mb-2" required value="<?php echo $data['Rent']; ?>">
                                <input type="text" name="Garbage" placeholder=" Garbage" class="form-control mb-2" required value="<?php echo $data['Garbage']; ?>">
                                <input type="text" name="Water" placeholder=" Water" class="form-control mb-2" required value="<?php echo $data['Water']; ?>">
                                <input type="Date" name="Date" placeholder=" Date Due" class="form-control mb-2" required value="<?php echo $data['DateDue']; ?>">
                        </div>
                    <div class="card-footer">
                            <button class="btn btn-success" name="btn_update"> Update </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>