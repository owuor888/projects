<?php 
    require_once('./Package_config/dbconfig.php'); 
    $db = new operations();
    $db->update();
    $id = $_GET['U_ID'];
    $result = $db->get_record($id);
    $data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>Edit Package</title>
</head>
<body class="bg-dark">

    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2> PACKAGE NOTIFICATION </h2>
                    </div>
                        <?php $db->Store_Record(); ?>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="ID" value="<?php echo $data['ID']; ?>">
                                <input type="text" name="Owner" placeholder=" Package Owner" class="form-control mb-2" required value="<?php echo $data['PackageOwner']; ?>">
                                <input type="text" name="Name" placeholder=" Apartment Name" class="form-control mb-2" required value="<?php echo $data['ApartmentName']; ?>">
                                <input type="text" name="Details" placeholder=" Package Details" class="form-control mb-2" required value="<?php echo $data['PackageDetails']; ?>">
                                <input type="text" name="Status" placeholder=" Status" class="form-control mb-2" required value="<?php echo $data['Status']; ?>">
                        </div>
                    <div class="card-footer">
                            <button class="btn btn-success" name="btn_update"> Update </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>