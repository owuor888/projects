<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Tenant Menu</title>
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
	<link rel="shortcut icon" href="../favicon.ico"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style4.css" />
	<script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
  </head>
  <body>
  <ul class="cb-slideshow">
            <li><span>Image 01</span><div><h3>se·ren·i·ty</h3></div></li>
            <li><span>Image 02</span><div><h3>com·po·sure</h3></div></li>
            <li><span>Image 03</span><div><h3>e·qua·nim·i·ty</h3></div></li>
            <li><span>Image 04</span><div><h3>bal·ance</h3></div></li>
            <li><span>Image 05</span><div><h3>qui·e·tude</h3></div></li>
            <li><span>Image 06</span><div><h3>re·lax·a·tion</h3></div></li>
        </ul>
		

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <h3> NYAYO NYUMBA <span>KUMI</span> MANAGEMENT</h3>
      </div>
      <div class="right_area">
        <a href="logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <img src="images/1.png" class="profile_image" alt="">
        <h4><?php echo $_SESSION['username'] ?></h4>
      </center>
      <a href="#"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
	  <a href="Report Issue.html"><i class="fas fa-sliders-h"></i><span>Report issue</span></a>
	   <a href="view2_apartment.php"><i class="fas fa-sliders-h"></i><span>View Apartments</span></a>
      <a href="view2_rent.php"><i class="fas fa-cogs"></i><span>Rent & Utilities</span></a>
      <a href="view2_package.php"><i class="fas fa-table"></i><span>Package Notifications</span></a>
      <a href="Store Document.php"><i class="fas fa-th"></i><span>Store Documents</span></a>
	   <a href="Downloads.php"><i class="fas fa-info-circle"></i><span>View Documents</span></a>
	   <a href="view2_payment.php"><i class="fas fa-info-circle"></i><span>Payments</span></a>
	  <a href="Emergency Info.html"><i class="fas fa-info-circle"></i><span>Emergency Info</span></a>
      
    </div>
    <!--sidebar end-->

    <div class="content"></div>

<!--bottom section start-->
	 <div class="bottom">
        <center>
          <span class="credit">Created By <a href="#">OWUOR NICHOLAS OMONDI</a> | </span>
          <span class="far fa-copyright"></span><span> 2020 All rights reserved.</span>
        </center>
      </div>
<!--bottom section end-->
  </body>
</html>