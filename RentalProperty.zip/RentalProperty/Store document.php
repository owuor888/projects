<?php include 'filesLogic.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="css/style5.css">
    <title>Files Upload and Download</title>
  </head>
  <body>
  
<style>
body{
	background-image:url('images/1.jpg');
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:100% 100%;
}
</style>
	

    <div class="container">
      <div class="row">
        <form action="Store document.php" method="post" enctype="multipart/form-data" >
          <h3>Upload File</h3>
          <input type="file" name="myfile"> <br>
          <button type="submit" name="save">upload</button>
        </form>
      </div>
    </div>
  </body>
</html>