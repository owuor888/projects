-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2020 at 10:51 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rentalproperty`
--

-- --------------------------------------------------------

--
-- Table structure for table `apartment`
--

CREATE TABLE `apartment` (
  `ID` int(100) NOT NULL,
  `ApartmentName` varchar(100) NOT NULL,
  `ApartmentType` varchar(100) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apartment`
--

INSERT INTO `apartment` (`ID`, `ApartmentName`, `ApartmentType`, `Location`, `Status`) VALUES
(1, '1A', '3BEDROOMS', '1st Floor', 'OCCUPIED'),
(2, '1B', '3BEDROOMS', '1st Floor', 'Occupied'),
(4, '1C', '2BEDROOMS', '1st Floor', 'OCCUPIED'),
(5, '1D', '2BEDROOMS', '1st Floor', 'OCCUPIED'),
(6, '2A', 'SINGLE BEDROOM', '2nd Floor', 'OCCUPIED');

-- --------------------------------------------------------

--
-- Table structure for table `emergencyinfo`
--

CREATE TABLE `emergencyinfo` (
  `ID` int(100) NOT NULL,
  `ApartmentName` varchar(100) NOT NULL,
  `ApartmentOwner` varchar(100) NOT NULL,
  `EmergencyInfo` varchar(100) NOT NULL,
  `Urgency` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emergencyinfo`
--

INSERT INTO `emergencyinfo` (`ID`, `ApartmentName`, `ApartmentOwner`, `EmergencyInfo`, `Urgency`) VALUES
(1, '1A', 'Deborah', 'Faulty Electricity Socket', 'Urgent');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `size` int(100) NOT NULL,
  `downloads` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `size`, `downloads`) VALUES
(1, 'Deborah Receipt.pdf', 47383, '0'),
(2, 'Raphael receipt.pdf', 47878, '0');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `ID` int(100) NOT NULL,
  `PackageOwner` varchar(100) NOT NULL,
  `ApartmentName` varchar(100) NOT NULL,
  `PackageDetails` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`ID`, `PackageOwner`, `ApartmentName`, `PackageDetails`, `Status`) VALUES
(1, 'Deborah', '1A', 'Brown Envelop', 'NOT TAKEN');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `ID` int(100) NOT NULL,
  `ApartmentName` varchar(100) NOT NULL,
  `ApartmentOwner` varchar(255) NOT NULL,
  `AmountPaid` varchar(100) NOT NULL,
  `DatePaid` date NOT NULL,
  `PaymentStatus` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`ID`, `ApartmentName`, `ApartmentOwner`, `AmountPaid`, `DatePaid`, `PaymentStatus`) VALUES
(1, '1A', 'DEBORAH SHILAKO', 'KShs..5000', '2020-09-10', 'KShs. 0.00'),
(2, '1B', 'RAPHAEL OKUMU', 'KSHs.3000', '2020-10-09', '  KShs.2000 Blc');

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `ID` int(100) NOT NULL,
  `Rent` varchar(100) NOT NULL,
  `Garbage` varchar(100) NOT NULL,
  `Water` varchar(100) NOT NULL,
  `DateDue` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`ID`, `Rent`, `Garbage`, `Water`, `DateDue`) VALUES
(1, 'KSHs. 5000', 'KSHs. 100', 'KSHs. 500', '2020-09-30');

-- --------------------------------------------------------

--
-- Table structure for table `reportissue`
--

CREATE TABLE `reportissue` (
  `ID` int(100) NOT NULL,
  `ApartmentName` varchar(100) NOT NULL,
  `ProblemDescription` varchar(100) NOT NULL,
  `WhereExperienced` varchar(100) NOT NULL,
  `Urgency` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reportissue`
--

INSERT INTO `reportissue` (`ID`, `ApartmentName`, `ProblemDescription`, `WhereExperienced`, `Urgency`) VALUES
(1, '1A', 'Water Leakage', '1st Floor', 'Urgent');

-- --------------------------------------------------------

--
-- Table structure for table `userinfotable`
--

CREATE TABLE `userinfotable` (
  `ID` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `ApartmentName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userinfotable`
--

INSERT INTO `userinfotable` (`ID`, `username`, `password`, `fullname`, `ApartmentName`) VALUES
(1, 'admin', 'admin1234', 'RPM ADMIN', 'Admin'),
(2, 'Deborah', '1234', 'Deborah Shilako', '1A'),
(3, 'Teddy', 'asdf', 'Raphael Teddy', '1B'),
(4, 'Nicholas', '0000', 'Nicholas Owuor', '1C'),
(5, 'Felix', '2020', 'Felix Ochieng\'', '1D'),
(6, 'Tommy', '1234', 'Tommy C. O.', '2A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apartment`
--
ALTER TABLE `apartment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `emergencyinfo`
--
ALTER TABLE `emergencyinfo`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reportissue`
--
ALTER TABLE `reportissue`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userinfotable`
--
ALTER TABLE `userinfotable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apartment`
--
ALTER TABLE `apartment`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `emergencyinfo`
--
ALTER TABLE `emergencyinfo`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rent`
--
ALTER TABLE `rent`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reportissue`
--
ALTER TABLE `reportissue`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userinfotable`
--
ALTER TABLE `userinfotable`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
